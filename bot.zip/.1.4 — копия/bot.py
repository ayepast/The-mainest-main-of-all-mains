import os
import telebot
from telebot.types import (
    ReplyKeyboardMarkup, 
    KeyboardButton, 
    WebAppInfo,
    InlineKeyboardMarkup,
    InlineKeyboardButton
)
import random
import pyautogui
import os
from time import sleep, time
bot = telebot.TeleBot("8236121440:AAHEs81w0qmbwOU41eCx_9tpFs-1nDVPIbU", parse_mode="HTML")
print(os.listdir("images"))
@bot.message_handler(commands=['mem'])
def send_mem(message):
    h = os.listdir("images")
    rand = random.choice(h)
    with open(f'images/{rand}', 'rb') as f:  
        bot.send_photo(message.chat.id, f)  

@bot.message_handler(commands=["start"])
def start(message):
    bot.reply_to(message,"Привет! напиши /mem и увидишь сюрприз")

@bot.message_handler()
def mes(message):
    text = message.text
    if str.find(text,"67") != -1:
        with open("67/idk.jpg",'rb') as f:
            bot.send_photo(message.chat.id, f) 

bot.polling(non_stop=True)